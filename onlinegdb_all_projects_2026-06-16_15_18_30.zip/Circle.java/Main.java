/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;
class Circle {
    double r, area;
    public void getdata() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter r:");
        r = in.nextDouble();
        in.close();
    }
    public void calc() {
        area = Math.PI * r * r;
        System.out.println("Area = " + area);
    }
}
class Main {
    public static void main(String[] args) {
        Circle obj = new Circle();
        obj.getdata();
        obj.calc();
    }
}

