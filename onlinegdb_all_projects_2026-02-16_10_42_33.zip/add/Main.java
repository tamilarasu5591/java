/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
class add{
    public static void public static void main (String[] args) {
        long=a,b;
        System.out.println("enter a:" );
        a=in.nextlong();
        System.out.println("enter b:" );
        b=in.nextlong();
        System.out.println(a+b);
        
    }
}